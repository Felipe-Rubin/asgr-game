

**Tiles**
https://opengameart.org/content/castle-tiles-for-rpgs
https://opengameart.org/content/castle-tiles-for-rpgs
https://www.newgrounds.com/art/view/hyptosis/tile-art-batch-1


**Guides**:
https://www.youtube.com/watch?v=LNLVOjbrQj4